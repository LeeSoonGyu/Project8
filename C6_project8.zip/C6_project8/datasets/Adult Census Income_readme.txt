성인 인구조사 소득 예측
age: 나이
workclass: 고용 형태
fnlwgt: 사람의 대표성을 나타내는 가중치(final weight)
education: 교육 수준
education.num: 교육 수준 수치
marital.status: 결혼 상태
occupation: 업종
relationship: 가족 관계
race: 인종
sex: 성별
capital.gain: 양도 소득
capital.loss: 양도 손실
hours.per.week: 주당 근무 시간
native.country: 국적
income: 수익 (예측해야 하는 값)